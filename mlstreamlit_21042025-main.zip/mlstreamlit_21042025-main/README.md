# mlstreamlit_21042025
for caltech class
